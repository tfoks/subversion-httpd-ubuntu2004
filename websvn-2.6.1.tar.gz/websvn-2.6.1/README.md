# WebSVN - Online Subversion repository browser

This is a Fork from WebSVN

WebSVN offers a view onto your Subversion repositories that's been designed to reflect the Subversion methodology. 
You can view the log of any file or directory and see a list of all the files changed, added or deleted in any given revision. 
You can also view the differences between two versions of a file so as to see exactly what was changed in a particular revision.

More information in project site. https://websvnphp.github.io/
