Icons have been selected (and sometimes adapted) from the following icon sets:

Fugue       - http://www.pinvoke.com
Led         - http://led24.de/iconset/
RSS Icons   - http://www.icojoy.com/articles/23/
Splashyfish - http://splashyfish.com/icons/
Vaga        - http://www.edmerritt.com

Some of the icons have been drawn from or influenced by Mac OS X.
