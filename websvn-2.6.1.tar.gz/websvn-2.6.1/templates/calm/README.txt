 ______________________________________________________________________________
|                                                                              |
|                            "CALM" THEME FOR WEBSVN                           |
|                                                                              |
|              (Theme : http://calm-theme-for-websvn.devjavu.com)              |
|______________________________________________________________________________|
 ______________________________________________________________________________
|                                                                              |
|      Copyright 2007  Erik Poehler    (email : iroybot@gmail.com)             |
|                                      (blog  : http://contactsheet.de)        |
|                                                                              |
|   This program is free software; you can redistribute it and/or modify       |
|   it under the terms of the GNU General Public License as published by       |
|   the Free Software Foundation; either version 2 of the License, or          |
|   (at your option) any later version.                                        |
|                                                                              |
|   This program is distributed in the hope that it will be useful,            |
|   but WITHOUT ANY WARRANTY; without even the implied warranty of             |
|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              |
|   GNU General Public License for more details.                               |
|                                                                              |
|   You should have received a copy of the GNU General Public License          |
|   along with this program; if not, write to the Free Software                |
|   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA   |
|______________________________________________________________________________|
 ______________________________________________________________________________
|                                                                              |
|  INSTALLATION                                                                |
|______________________________________________________________________________|
 
  1)  Place the complete directory "calm" in your "templates" directory/
  
  2)  Open include/config.php and look for a line similar to the following:
  
      $config->setTemplatePath("$locwebsvnreal/templates/Standard/");

      and change it into:

      $config->setTemplatePath("$locwebsvnreal/templates/calm/");

  3)  Enjoy.
  
  If you like the template, please feel free to donate
  some cents via paypal to erikpoehler@gmx.de.
  
  In case you found errors, bugs or have improvement suggestions,
  send me a email or visit:
  
  http://calm-theme-for-websvn.devjavu.com
  
  Please keep the backlink in the footer intact. Thanks.
 ______________________________________________________________________________
|                                                                              |
|  CREDITS                                                                     |
|______________________________________________________________________________|
 
  1. Icons picked from: "Sweetie", "Silk" and "Tango" Iconsets. Much Thanks to the creators.
  
  2. Dean Edwards for making his "star-light" Syntax Highlighting available.
  
  3. You for developing (hopefully good) software.
